echo $(whoami)$(date +%s) | head -c -1 > password.txt
